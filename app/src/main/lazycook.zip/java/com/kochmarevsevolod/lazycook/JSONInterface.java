package com.kochmarevsevolod.lazycook;

import org.json.JSONArray;

public interface JSONInterface {
    void fill_spinner(JSONArray result);
    void set_seekbar_parameters(JSONArray result);
}
